This code hilights an "inconsistenly fucked" part of Xlib.
It will take the C- but not the equivalent Pascal- to do the same thing.

The event handler code crashes the application.
