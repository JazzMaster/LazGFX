cd ..
find ./ \( -name '*.o' -o -name '*.ppu' -o -name '*.a' \) -exec rm {} \+


