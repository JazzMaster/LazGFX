cd ..
find src/ \( -name '*.o' -o -name '*.ppu' -o -name '*.a' \) -exec rm {} \+


