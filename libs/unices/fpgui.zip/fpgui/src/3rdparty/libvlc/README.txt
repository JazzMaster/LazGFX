
VLC Library 2.x

This directory contains header translations of the VLC library v2.x, as well
as unit containing a non-gui Media Player class. There is also a fpGUI Media
Player descendant class added, which allows you to embed the video output
inside a fpGUI widget.

This code was commissioned by Master Maths [http://www.mastermaths.co.za]
(my employer), and kindly donated to the Free Pascal and fpGUI Toolkit
projects.
