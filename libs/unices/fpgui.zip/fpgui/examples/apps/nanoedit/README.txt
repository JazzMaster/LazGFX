Title:   nanoedit
Author:  Graeme Geldenhuys <graemeg@gmail.com>
Description:
------------
I often need a Notepad like (very basic) editor on non-Windows platforms,
for some of my other projects. I created nanoedit for that reason. I'm
also using nanoedit as a testing platform for the fpg_textedit unit
(part of the Maximus IDE example project), and for my experimental 
"elastic tabstops" [http://nickgravgaard.com/elastictabstops/]
implementation.
