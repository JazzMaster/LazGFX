This is a small example just to show that fpGUI widgets can be used
as DB-aware widgets too.