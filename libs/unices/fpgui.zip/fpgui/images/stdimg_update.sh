#!/bin/sh
chmod +x updatestdimgs
./updatestdimgs -p stdimg > ../src/corelib/stdimages.inc
