

http://www.unicode.org/Public/MAPPINGS/VENDORS/MICSFT/PC/

The URL above shows various codepage character mappings from
 XXX to Unicode.
 
See the .ipf file for the valid codepage options used in IPF format.

