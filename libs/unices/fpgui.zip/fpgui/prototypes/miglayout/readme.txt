
  MiG Layout Manager
  ------------------

This directory contains the beginnings of my port of the MiG Layout 
Manager v3.0.3 from Java to Object Pascal. This is still in the very
early stages, so I have nothing visual to show yet.

For more information about the MiG Layout (Java Layout Manager) for 
Swing and SWT please visit:  http://www.miglayout.com/

Regards,
  - Graeme -

          ------------------------------------
