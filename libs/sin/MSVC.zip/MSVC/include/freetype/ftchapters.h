/***************************************************************************/
/*                                                                         */
/* <Chapter>                                                               */
/*    core_api                                                             */
/*                                                                         */
/* <Title>                                                                 */
/*    Core API                                                             */
/*                                                                         */
/* <Sections>                                                              */
/*    basic_types                                                          */
/*    base_interface                                                       */
/*    glyph_management                                                     */
/*    mac_specific                                                         */
/*    sizes_management                                                     */
/*    header_file_macros                                                   */
/*                                                                         */
/***************************************************************************/

/***************************************************************************/
/*                                                                         */
/* <Chapter>                                                               */
/*    format_specific                                                      */
/*                                                                         */
/* <Title>                                                                 */
/*    Format-Specific API                                                  */
/*                                                                         */
/* <Sections>                                                              */
/*    multiple_masters                                                     */
/*    truetype_tables                                                      */
/*    type1_tables                                                         */
/*    sfnt_names                                                           */
/*    bdf_fonts                                                            */
/*    pfr_fonts                                                            */
/*                                                                         */
/***************************************************************************/


/***************************************************************************/
/*                                                                         */
/* <Chapter>                                                               */
/*    cache_subsystem                                                      */
/*                                                                         */
/* <Title>                                                                 */
/*    Cache Sub-System                                                     */
/*                                                                         */
/* <Sections>                                                              */
/*    cache_subsystem                                                      */
/*                                                                         */
/***************************************************************************/


/***************************************************************************/
/*                                                                         */
/* <Chapter>                                                               */
/*    support_api                                                          */
/*                                                                         */
/* <Title>                                                                 */
/*    Support API                                                          */
/*                                                                         */
/* <Sections>                                                              */
/*    computations                                                         */
/*    list_processing                                                      */
/*    outline_processing                                                   */
/*    raster                                                               */
/*    system_interface                                                     */
/*    module_management                                                    */
/*                                                                         */
/***************************************************************************/

