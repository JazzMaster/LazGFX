#ifndef _ALUTTYPES_H_
#define _ALUTTYPES_H_

#define AL_PROVIDES_ALUT                          1

#endif /* _ALUTTYPES_H_ */
